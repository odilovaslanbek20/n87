// 1-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");

// text2.style.display = "none";
// btn.onclick = function () {
//     myCount(text1.value, out);
//     text1.value = '';
// }

// function myCount(a, c) {
//     c.innerHTML = "Hello " + a + "!";
// }

// ================================================================================

// 2-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");

// btn.onclick = function () {
//     myCount(text1.value, text2.value, out);
//     text1.value = '';
//     text2.value = '';
// }

// function myCount(a, b, c) {
//     c.innerHTML = a + b + b + a;
// }

// // ================================================================================

// // 3-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");

// text1.placeholder = 'Ixtiyoriy HTML tag kirit';
// text2.placeholder = "Ixtiyoriy so'z kirit";
// btn.onclick = function () {
//     myCount(text1.value, text2.value, out);
//     text1.value = '';
//     text2.value = '';
// }

// function myCount(a, b, c) {
//     c.innerHTML = `<${a}>${b}</${a}>`;
// }


// // ================================================================================

// // 4-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");

// btn.onclick = function () {
//     myCount(text1.value, text2.value, out);
//     text1.value = '';
//     text2.value = '';
// }

// function myCount(a, b, c) {
//     c.innerHTML = a.slice(0,2) + b + a.slice(-2);
// }

// ================================================================================

// 5-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");
// text2.style.display = "none";
// btn.onclick = function () {
//     myCount(text1.value, out);
//     text1.value = '';
// }

// function myCount(a, c) {
//     c.innerHTML = a.slice(-2).repeat(3);
// }

// // ================================================================================

// // 6-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");
// text2.style.display = "none";
// btn.onclick = function () {
//     myCount(text1.value, out);
//     text1.value = '';
// }

// function myCount(a, c) {
//     c.innerHTML = a;
// }

// // // ================================================================================

// // // 7-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");
// text2.style.display = "none";
// btn.onclick = function () {
//     myCount(text1.value, out);
//     text1.value = '';
// }

// function myCount(a, c) {
//     c.innerHTML = a.slice(1, -1);
// }

// // // ================================================================================

// // // 8-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");

// btn.onclick = function () {
//     myCount(text1.value, text2.value, out);
//     text1.value = '';
//     text2.value = '';
// }

// function myCount(a, b, c) {
//      if(a.length < b.length){
//         c.innerHTML =  a + b + a
//      }else{
//         c.innerHTML =  b + a + b
//      };
// }


// // // ================================================================================

// // // 9-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");

// btn.onclick = function () {
//     myCount(text1.value, text2.value, out);
//     text1.value = '';
//     text2.value = '';
// }

// function myCount(a, b, c) {
//         c.innerHTML =  a.slice(1) + b.slice(1)
// }

// // // ================================================================================

// // // 10-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");
// text2.style.display = "none";
// btn.onclick = function () {
//     myCount(text1.value, out);
//     text1.value = '';
// }

// function myCount(a, c) {
//         c.innerHTML =  a.slice(2) + a.slice(0, 2)
// }

// // // ================================================================================

// // // 11-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");
// text2.style.display = "none";
// btn.onclick = function () {
//     myCount(text1.value, out);
//     text1.value = '';
// }

// function myCount(a, c) {
//         c.innerHTML =  a.substring(a.length -2) + a.substring(0, a.length -2)
// }

// // // ================================================================================

// // // 12-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");
// text2.placeholder = "Faqat tru yoki false qiymat kirit";
// btn.onclick = function () {
//     myCount(text1.value, text1.value, out);
//     text1.value = '';
//     text2.value = '';
// }

// function myCount(a, b, c) {
//          if(b === true){
//             c.innerHTML = a.slice(0, 1)
//          }else{
//             c.innerHTML = a.slice(-1)
//          }
// }

// // // ================================================================================

// // // 13-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");
// text2.style.display = "none";
// btn.onclick = function () {
//     myCount(text1.value, out);
//     text1.value = '';
// }

// function myCount(a, c) {
//     if(a.length > 2){
//         c.innerHTML = a.slice(1, -1)
//       }else{
//         c.innerHTML = '';
//       }
// }

// // // ================================================================================

// // // 14-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");
// text2.style.display = "none";
// btn.onclick = function () {
//     myCount(text1.value, out);
//     text1.value = '';
// }

// function myCount(a, c) {
//     if(a === "123456789"){
//         c.innerHTML = '123456789'
//       }else{
//         c.innerHTML = '';
//       }
// }


// // // ================================================================================

// // // 15-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");
// text2.style.display = "none";
// btn.onclick = function () {
//     myCount(text1.value, out);
//     text1.value = '';
// }

// function myCount(a, c) {
//     if (a.endsWith("ly")) {
//         c.innerHTML = true
//     } else {
//         c.innerHTML = false      
//     }
// }


// // // ================================================================================

// // // 16-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");
// text2.placeholder = "Faqat Number qiymat kirit";
// btn.onclick = function () {
//     nTwice(text1.value, text2.value, out);
//     text1.value = '';
//     text2.value = '';
// }

// function nTwice(str, n, o){
//     o.innerHTML = str.substring(0, n) + str.substring(str.length - n)
//   }


// // // ================================================================================

// // // 17-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");
// text2.placeholder = "Faqat Number qiymat kirit";
// btn.onclick = function () {
//     twoChar(text1.value, text2.value, out);
//     text1.value = '';
//     text2.value = '';
// }

// function twoChar(str, index, o){
//     if (index < 0 || index > str.length - 2) {
//     o.innerHTML = str.slice(0, 2);
//   }
  
//   o.innerHTML = str.slice(index, index + 2);
// }

// // // ================================================================================

// // // 18-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");
// text2.style.display = "none";
// btn.onclick = function () {
//     middleThree(text1.value, out);
//     text1.value = '';
// }

// function middleThree(str, o){
//     let middleIndex = Math.floor(str.length / 2); 
//    o.innerHTML = str.slice(middleIndex - 1, middleIndex + 2); 
//  }

// // // ================================================================================

// // // 19-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");
// text2.style.display = "none";
// btn.onclick = function () {
//     hasBad(text1.value, out);
//     text1.value = '';
// }

// function hasBad(str, o){
//     if (str.startsWith("bad", 0) || str.startsWith("bad", 1)) {
//         o.innerHTML = 'True';
//     } else {
//         o.innerHTML = 'False';
//     }
//   }

// // // ================================================================================

// // // 20-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");
// text2.style.display = "none";
// btn.onclick = function () {
//     hasBad(text1.value, out);
//     text1.value = '';
// }

// function hasBad(str, o){
//     if (str.length > 1) {
//         o.innerHTML = str.slice(0, 2);
//     } else {
//         o.innerHTML = str.padEnd(2, '@');
//     }
//   }

// // // ================================================================================

// // // 21-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");

// btn.onclick = function () {
//     lastChars(text1.value, text2.value, out);
//     text1.value = '';
//     text2.value = '';
// }

// function lastChars(a, b, o){
//     let c = a.length > 0 ? a[0] : "@";
//     let s = b.length > 0 ? b[b.length - 1] : "@";
//     o.innerHTML = c + s;
// }

// // // ================================================================================

// // // 22-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");

// btn.onclick = function () {
//     conCat(text1.value, text2.value, out);
//     text1.value = '';
//     text2.value = '';
// }

// function conCat(a, b, o){
//     if(a === '' || b === '') o.innerHTML = a + b;
   
//     if(a[a.length -1] === b[0]){
//         o.innerHTML = a + b.substring(1);
//     }
//    o.innerHTML = a + b;
//  }

// // // ================================================================================

// // // 23-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");
// text2.style.display = "none";
// btn.onclick = function () {
//     lastTwo(text1.value, out);
//     text1.value = '';
// }

// function lastTwo(str, o){
//     if(str.length < 2) o.innerHTML = str;
    
//     let a = str.slice(0, -2);
//     let b = str.slice(-1) + str.slice(-2, -1)
    
//     o.innerHTML = a + b
//   }


// // // ================================================================================

// // // 24-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");
// text2.style.display = "none";
// btn.onclick = function () {
//     seeColor(text1.value, out);
//     text1.value = '';
// }

// function seeColor(str, o) {
//     if(str.startsWith('red')){
//         o.innerHTML = 'red' 
//     }else if(str.startsWith('blue')){
//         o.innerHTML = 'blue'  
//     }else{
//         o.innerHTML = '';
//     }
// }


// // // ================================================================================

// // // 25-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");
// text2.style.display = "none";
// btn.onclick = function () {
//     frontAgain(text1.value, out);
//     text1.value = '';
// }

// function frontAgain(str, o){
//     if(str.length < 2) o.innerHTML = 'False';
    
//     let a = str.slice(0, 2);
//     let b = str.slice(-2);

//     if (a === b) {
//         o.innerHTML = 'True'
//     } else {
//         o.innerHTML = 'False'
//     }
//   }

// // // ================================================================================

// // // 26-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");

// btn.onclick = function () {
//     minCat(text1.value, text2.value, out);
//     text1.value = '';
//     text2.value = '';
// }

// function minCat(a, b, o){
//     let c = Math.min(a.length, b.length);
//     if(c === 0) o.innerHTML = '';
//     let i = a.slice(-c);
//     let g = b.slice(-c);
//     o.innerHTML = i + g;
//   }


// // // ================================================================================

// // // 27-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");
// text2.style.display = 'none';
// btn.onclick = function () {
//     minCat(text1.value, out);
//     text1.value = '';
// }

// function minCat(a, o){
//     o.innerHTML = a.slice(0, 2).repeat(3);
// }

// // // ================================================================================

// // // 28-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");
// text2.style.display = 'none';
// btn.onclick = function () {
//     without2(text1.value, out);
//     text1.value = '';
// }

// function without2(str, o){
//     if (str.length >= 2 && str.slice(0, 2) === str.slice(-2)) {
//         o.innerHTML = str.slice(2); 
//    }else{
//        o.innerHTML = str;
//    }
//  }

// // // ================================================================================

// // // 29-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");
// text2.style.display = 'none';
// btn.onclick = function () {
//     deFront(text1.value, out);
//     text1.value = '';
// }

// function deFront(str, o){
//     let count = '';
//     if(str.length > 0 && str[0] === 'a'){
//        count += str[0]
//     }
//     if(str.length > 1 && str[1] === 'b'){
//        count += str[1]
//     }
//     o.innerHTML = count + str.slice(2)
//   }

// // // ================================================================================

// // // 30-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");

// btn.onclick = function () {
//     startWord(text1.value, text2.value, out);
//     text1.value = '';
//     text2.value = '';
// }

// function startWord(str, word, o){
//     if (str.substring(1, word.length) === word.substring(1)) {
//           o.innerHTML = str.substring(0, word.length);
//       }else{
//           o.innerHTML = "";
//       }
//   }

// // // ================================================================================

// // // 31-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");
// text2.style.display = 'none';
// btn.onclick = function () {
//     withoutX(text1.value, out);
//     text1.value = '';
// }

// function withoutX(str){
//     if(str.length === 0) out.innerHTML = str;
    
//     if(str.startsWith('x')){
//        str = str.substring(1)
//     }
   
//    if (str.endsWith("x")) {
//          str = str.substring(0, str.length - 1);
//      }
   
//    out.innerHTML = str;
//  }


// // // ================================================================================

// // // 32-masal

// let text1 = document.getElementById("text1");
// let text2 = document.getElementById("text2");
// let btn = document.getElementById("btn");
// let out = document.getElementById("out");
// text2.style.display = 'none';
// btn.onclick = function () {
//     withoutX2(text1.value, out);
//     text1.value = '';
// }

// function withoutX2(str, o){
//     if (str.length > 1 && str[0] === 'x' && str[1] === 'x') {
//       o.innerHTML = str.slice(2);
//     } else if (str[0] === 'x') {
//         o.innerHTML = str.slice(1);
//     } else if (str[1] === 'x') {
//         o.innerHTML = str[0] + str.slice(2);
//     } else {
//         o.innerHTML = str;
//     }
//   }

