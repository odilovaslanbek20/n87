let left = document.querySelector(".cards__left");
let center = document.querySelector(".cards__center");
let right = document.querySelector(".cards__right");
let right1 = document.querySelector(".cards__right i");
let rest = document.querySelector(".bg__cards");
let select = document.getElementById("select");
let like = document.querySelector(".like1");
let like1 = document.querySelector(".like2");
let like__cards = document.querySelector(".like__cards");
let like__text = document.querySelector(".like__text");
let container = document.querySelector(".container");
let img = document.querySelector(".img");
let body = document.querySelector("body");

export {left, center, right, right1, rest, select, like, like1, like__cards, like__text, container, img, body};