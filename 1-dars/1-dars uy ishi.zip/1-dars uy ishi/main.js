// 1-masala
// let sm = prompt("Ixtiyoriy sm kriting...")
// let mm = 100;
// console.log("Siz kiritgan son" + " " + sm / mm + " " + "metrga teng...");

// ===================================================================

// 2-masala
// let kg = prompt("Ixtiyoriy son kriting...")
// let ton = 1000;
// console.log("Siz kiritgan son" + " " + kg / ton + " " + "tonaga teng...");

// ==============================================================================

// 3-masala
// let file = 2994858.245;
// let kb = 1024;
// let int = parseInt(file);
// console.log("Sizning filelingiz" + " " + parseInt(int / kb) + " " + "kilobayt...");

// ============================================================================

// 4-masala
// let uznlik = parseInt(prompt("200 dan pas bo'lgan ixtiyoriy uzunlikni kiriting..."));
// let uznlik2 = 200;
// console.log("Siz kiritgan uzunlik joriy uzunlik ichida" + " " + parseInt(uznlik2 / uznlik) + " " + "marta yotadi...");

// =========================================================================================

// 5-masala
// let uznlik = parseInt(prompt("300 dan pas bo'lgan ixtiyoriy uzunlikni kiriting..."));
// let uznlik2 = 300;
// console.log("Siz kiritgan uzunlik joriy uzunlik ichida" + " " + parseInt(uznlik2 / uznlik) + " " + "marta yotadi...");
// console.log("Siz kiritgan uzunliknik joriy uzunlik ichida" + " " + parseInt(uznlik2 % uznlik) + "sm " + "joylashmay qolgan qismi...");

// ============================================================================

// 6-masala
// let son = prompt("Ikki yoki undan ko'p xonali bo'lgan ixtiyoriy son kiriting...")
// let a = parseInt(son / 10);
// let b = son % 10;
// console.log("Siz kiritgan son 10liklar xonasidagi qiymati" + " " + a + " " + "ga teng...");
// console.log("Siz kiritgan son 1liklar xonasidagi qiymati" + " " + b + " " + "ga teng...");

// ============================================================================

// 7-masal
// let son = prompt("Ikki xonali bo'lgan ixtiyoriy son kiriting...");
// let a = parseInt(son / 10);
// let b = son % 10;
// let c = a+b
// console.log("Siz kiritgan ikki xonali sonning ikkala son yig'indisi" + " " + c + " " + "ga teng...");

// ============================================================================

// 8-masal
// let son = prompt("Ikki xonali bo'lgan ixtiyoriy son kiriting...");
// let a = parseInt(son / 10);
// let b = son % 10;
// console.log("Siz kiritgan ikki xonali sonning ikkala sonlarining o'rnini almashtirganda hosil bo'luvchi son" + " " + b+a + " " + "ga teng...");

// ============================================================================

// 9-masal
// let son = prompt("Uch xonali bo'lgan ixtiyoriy sonni kiriting...")
// let a = parseInt(son/100)
// console.log("Siz kiritgan sonning yuzliklar xonasidagi soni" + " " + a + " " + "ga teng...");

// ============================================================================

// 10-masal
// let son = prompt("Uch xonali bo'lgan ixtiyoriy son kiriting...");
// let a = parseInt(son / 10);
// let b = son % 10;
// console.log("Siz kiritgan son 10liklar xonasidagi qiymati" + " " + a + " " + "ga teng...");
// console.log("Siz kiritgan son 1liklar xonasidagi qiymati" + " " + b + " " + "ga teng...");

// ============================================================================

// 11-masal
// let son = prompt("Uch xonali bo'lgan ixtiyoriy son kiriting...");
// let a = parseInt(son/100);
// let b = parseInt(son/10%10);
// let c = son%10;
// let v = a+b+c;
// console.log("Siz kiritgan uch xonali sonning uchala son yig'indisi" + " " + v + " " + "ga teng...");

// ============================================================================

// 12-masal
// let son = prompt("Uch xonali bo'lgan ixtiyoriy son kiriting...");
// let a = parseInt(son / 100);
// let b = parseInt((son / 10) % 10);
// let c = son % 10;
// console.log(
//   "Siz kiritgan uch xonali sonning uchala sonlarining o'rnini almashtirganda hosil bo'luvchi son" +
//     " " +
//     c +
//     b +
//     a +
//     " " +
//     "ga teng..."
// );

// ============================================================================

// 13-masal
// let son = prompt("Uch xonali bo'lgan ixtiyoriy son kiriting...");
// let a = parseInt(son / 100);
// let b = parseInt((son / 10) % 10);
// let c = son % 10;
// console.log(
//   "Siz kiritgan uch xonali sonning chapdan birinchi raqamini o'chirib o'ngdan birinchiga qo'yganda hosil bo'luvchi son" +
//     " " +
//     b +
//     c +
//     a +
//     " " +
//     "ga teng..."
// );
